let display = document.getElementById('display');

function appendToDisplay(value) {
    // Prevent multiple operators or dots in a row
    if (['+', '-', '*', '/', '.'].includes(value)) {
        if (display.value === '' || ['+', '-', '*', '/', '.'].includes(display.value.slice(-1))) {
            return;
        }
    }
    display.value += value;
}

function clearDisplay() {
    display.value = '';
}

function deleteLast() {
    display.value = display.value.slice(0, -1);
}

function calculateResult() {
    try {
        // Evaluate the expression and round to avoid floating point errors
        let result = eval(display.value);
        display.value = Math.round(result * 100000000) / 100000000;
    } catch (error) {
        display.value = 'Error';
        setTimeout(() => {
            display.value = '';
        }, 1000);
    }
}

// Allow keyboard input
document.addEventListener('keydown', function(event) {
    const key = event.key;

    if (key === 'Enter') {
        event.preventDefault();
        calculateResult();
    } else if (key === 'Backspace') {
        event.preventDefault();
        deleteLast();
    } else if (key === 'Escape') {
        event.preventDefault();
        clearDisplay();
    } else if (['+', '-', '*', '/', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(key)) {
        event.preventDefault();
        appendToDisplay(key);
    }
});